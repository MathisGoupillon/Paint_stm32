/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dac.h"
#include "dma2d.h"
#include "i2c.h"
#include "ltdc.h"
#include "rtc.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "fmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32746g_discovery_lcd.h"
#include "stm32746g_discovery_ts.h"
#include "stdio.h"
#include "HorombeRGB565.h"
#include "Scorvol.h"
#include <math.h>
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint32_t joystick_v;
uint32_t current_color = LCD_COLOR_BLACK;
int cursor_x = 10;
int cursor_y = 10;
int prev_cursor_x = 10;
int prev_cursor_y = 10;
int color_index = 0;
int cercle_etape = 0;
int centre_cercle_x, centre_cercle_y;
int bord_cercle_x, bord_cercle_y;

const uint32_t color_palette[] = {
	LCD_COLOR_RED, LCD_COLOR_BLUE, LCD_COLOR_GREEN, LCD_COLOR_YELLOW,
	LCD_COLOR_CYAN, LCD_COLOR_MAGENTA, LCD_COLOR_ORANGE, LCD_COLOR_LIGHTBLUE,
	LCD_COLOR_LIGHTGREEN, LCD_COLOR_BROWN, LCD_COLOR_GRAY, LCD_COLOR_WHITE, LCD_COLOR_BLACK
};
#define COLOR_COUNT (sizeof(color_palette) / sizeof(color_palette[0]))

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#define MAX_STACK_SIZE 10000

/**
 * Remplit récursivement une zone de même couleur à partir du point (x, y).
 * Style « étudiant » : noms explicites + beaucoup de commentaires.
 */
void flood_fill(int x, int y, uint32_t old_color, uint32_t new_color) {
    // 1) Vérifier que (x,y) est bien dans l'écran
    //    Ici, ton LCD fait 480×272 pixels
    if (x < 0 || x >= 480 || y < 0 || y >= 272) {
        return; // Sortie si on est hors écran
    }

    // 2) Lire la couleur actuelle du pixel
    uint32_t current = BSP_LCD_ReadPixel(x, y);

    // 3) Si ce pixel n'est pas de la couleur à remplacer, on s'arrête
    if (current != old_color) {
        return;
    }

    // 4) Sinon, on colore ce pixel avec la nouvelle couleur
    BSP_LCD_DrawPixel(x, y, new_color);

    // 5) Appel récursif sur les quatre voisins
    //    Voisin de droite
    flood_fill(x + 1, y,     old_color, new_color);
    //    Voisin de gauche
    flood_fill(x - 1, y,     old_color, new_color);
    //    Voisin du bas
    flood_fill(x,     y + 1, old_color, new_color);
    //    Voisin du haut
    flood_fill(x,     y - 1, old_color, new_color);

    // Fin de la fonction : la récursion remonte automatiquement
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
#include <math.h>

void DrawThickLine(int x0, int y0, int x1, int y1, int thickness, uint32_t color) {
    BSP_LCD_SetTextColor(color);

    int dx = x1 - x0;
    int dy = y1 - y0;
    int steps = fmax(abs(dx), abs(dy));

    float x_inc = dx / (float)steps;
    float y_inc = dy / (float)steps;

    float x = x0;
    float y = y0;

    for (int i = 0; i <= steps; i++) {
        BSP_LCD_FillCircle((int)x, (int)y, thickness / 2);
        x += x_inc;
        y += y_inc;
    }
}

/**
 * Lit un pixel et renvoie sa couleur codée en RGB565,
 * même si le framebuffer est en ARGB8888.
 */



int main(void)
{
  /* USER CODE BEGIN 1 */
#define Curseur 0
#define Segment 1
#define Cercle 2
#define Remplissage 3
#define Aide         4

	int rad=2;
	int etat=Curseur;
	int etat_precedent = Curseur;
	int vitesse;
	int bp1_new=1;
	int bp1_old=1;
	int bp2_new=1;
	int bp2_old=1;
	int pos_A_x_seg;
	int pos_A_y_seg;
	int pos_B_x_seg;
	int pos_B_y_seg;

	int centre_x = 2048;
	int centre_y = 2048;
	int zone_morte = 200;


	static TS_StateTypeDef  TS_State;
	uint32_t potl,potr,joystick_h,joystick_v;
	ADC_ChannelConfTypeDef sConfig = {0};
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC3_Init();
  MX_DMA2D_Init();
  MX_FMC_Init();
  MX_I2C1_Init();
  MX_I2C3_Init();
  MX_LTDC_Init();
  MX_RTC_Init();
  MX_SPI2_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM5_Init();
  MX_TIM8_Init();
  MX_USART1_UART_Init();
  MX_USART6_UART_Init();
  MX_ADC1_Init();
  MX_DAC_Init();
  MX_UART7_Init();
  /* USER CODE BEGIN 2 */
  BSP_LCD_Init();
  BSP_LCD_LayerDefaultInit(0, LCD_FB_START_ADDRESS);
  BSP_LCD_LayerDefaultInit(1, LCD_FB_START_ADDRESS+ BSP_LCD_GetXSize()*BSP_LCD_GetYSize()*4);
  BSP_LCD_DisplayOn();
  BSP_LCD_SelectLayer(0);
  BSP_LCD_Clear(LCD_COLOR_WHITE);
  //BSP_LCD_DrawBitmap(0,0,(uint8_t*)HorombeRGB565_bmp);
  BSP_LCD_SelectLayer(1);
  BSP_LCD_Clear(00);
  BSP_LCD_SetFont(&Font12);
  BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
  BSP_LCD_SetBackColor(00);

  BSP_TS_Init(BSP_LCD_GetXSize(), BSP_LCD_GetYSize());
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  BSP_LCD_SelectLayer(0);
  BSP_LCD_SetTextColor(LCD_COLOR_RED);
  BSP_LCD_FillRect(0, 252, 20, 20);
  BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
  BSP_LCD_FillRect(20, 252, 20, 20);
  BSP_LCD_SetTextColor(LCD_COLOR_GREEN);
  BSP_LCD_FillRect(40, 252, 20, 20);
  BSP_LCD_SetTextColor(LCD_COLOR_YELLOW);
  BSP_LCD_FillRect(60, 252, 20, 20);
  BSP_LCD_SetTextColor(LCD_COLOR_CYAN);
  BSP_LCD_FillRect(80, 252, 20, 20);
  BSP_LCD_SetTextColor(LCD_COLOR_MAGENTA);
  BSP_LCD_FillRect(100, 252, 20, 20);
  BSP_LCD_SetTextColor(LCD_COLOR_ORANGE);
  BSP_LCD_FillRect(120, 252, 20, 20);
  BSP_LCD_SetTextColor(LCD_COLOR_LIGHTBLUE);
  BSP_LCD_FillRect(140, 252, 20, 20);
  BSP_LCD_SetTextColor(LCD_COLOR_LIGHTGREEN);
  BSP_LCD_FillRect(160, 252, 20, 20);
  BSP_LCD_SetTextColor(LCD_COLOR_BROWN);
  BSP_LCD_FillRect(180, 252, 20, 20);
  BSP_LCD_SetTextColor(LCD_COLOR_GRAY);
  BSP_LCD_FillRect(200, 252, 20, 20);
  BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
  BSP_LCD_FillRect(220, 252, 20, 20);
  BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
  BSP_LCD_FillRect(240, 252, 20, 20);

  BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
  BSP_LCD_FillRect(0, 222, 30, 30);
  BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
  BSP_LCD_DrawRect(0, 222, 30, 30);
  BSP_LCD_DrawLine(5,227,25,248);

  // Rectangle pour le mode Curseur
  BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
  BSP_LCD_FillRect(0, 194, 30, 30); // rectangle blanc
  BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
  BSP_LCD_DrawRect(0, 194, 30, 30); // contour noir
  BSP_LCD_FillCircle(15, 209, 3);    // petit cercle noir au milieu = symbole du curseur

  BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
  BSP_LCD_FillRect(0, 164, 30, 30); // rectangle blanc
  BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
  BSP_LCD_DrawRect(0, 164, 30, 30); // contour noir
  BSP_LCD_DrawCircle(15, 179, 7); // symbole de cercle

  // Rectangle pour le mode Remplissage
  BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
  BSP_LCD_FillRect(0, 132, 30, 30); // rectangle blanc
  BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
  BSP_LCD_DrawRect(0, 132, 30, 30); // contour noir
  BSP_LCD_DrawLine(5, 149, 25, 149); // symbole de remplissage (barre horizontale)
  BSP_LCD_DrawLine(5, 153, 25, 153); // deuxième ligne

  // Rectangle pour le mode Aide
  BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
  BSP_LCD_FillRect(0, 104, 30, 30); // rectangle blanc au dessus
  BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
  BSP_LCD_DrawRect(0, 104, 30, 30); // contour noir
  // Dessiner un “?” au milieu
  BSP_LCD_SetFont(&Font16);
  BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
  BSP_LCD_DisplayStringAt(5, 109, (uint8_t *)"?", LEFT_MODE);



  BSP_LCD_SelectLayer(1);
  BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
  BSP_LCD_SetLayerVisible(1, ENABLE);
  BSP_LCD_SetTransparency(1, 255); // Curseur bien visible







  while (1)
  {
	  int last_etat = etat;
	  int is_on_palette = (cursor_y >= 250 && cursor_y <= 270);
	  bp1_new=HAL_GPIO_ReadPin(BP1_GPIO_Port,BP1_Pin);
	  bp2_new=HAL_GPIO_ReadPin(BP2_GPIO_Port,BP2_Pin);


		sConfig.Channel = ADC_CHANNEL_8;
		HAL_ADC_ConfigChannel(&hadc3, &sConfig);
		HAL_ADC_Start(&hadc3);
		while(HAL_ADC_PollForConversion(&hadc3, 100)!=HAL_OK);
		joystick_v = HAL_ADC_GetValue(&hadc3);

		HAL_ADC_Start(&hadc1);
		while(HAL_ADC_PollForConversion(&hadc1, 100)!=HAL_OK);
		joystick_h = HAL_ADC_GetValue(&hadc1);

		sConfig.Channel = ADC_CHANNEL_6;
		HAL_ADC_ConfigChannel(&hadc3, &sConfig);
		HAL_ADC_Start(&hadc3);
		while(HAL_ADC_PollForConversion(&hadc3, 100)!=HAL_OK);
		potr = HAL_ADC_GetValue(&hadc3);

		sConfig.Channel = ADC_CHANNEL_7;
		HAL_ADC_ConfigChannel(&hadc3, &sConfig);
		HAL_ADC_Start(&hadc3);
		while(HAL_ADC_PollForConversion(&hadc3, 100)!=HAL_OK);
		potl = HAL_ADC_GetValue(&hadc3);



		BSP_TS_GetState(&TS_State);
		if(TS_State.touchDetected){
			BSP_LCD_SetTextColor(current_color);
		}

		rad=(int)(potl*4/4092)+1;
		vitesse=(int)(potr*4/4095);
		BSP_LCD_SelectLayer(0);

		prev_cursor_x = cursor_x;
		prev_cursor_y = cursor_y;

		// Calcul du déplacement horizontal et vertical
		int deplacement_x = joystick_h - centre_x;
		int deplacement_y = joystick_v - centre_y;

		// On ignore les petits mouvements autour du centre
		if (abs(deplacement_x) < zone_morte) deplacement_x = 0;
		if (abs(deplacement_y) < zone_morte) deplacement_y = 0;

		// Si le joystick est suffisamment incliné, on déplace le curseur
		if (deplacement_x != 0 || deplacement_y != 0)
		{
		    float norme = sqrt(deplacement_x * deplacement_x + deplacement_y * deplacement_y);
		    float dir_x = deplacement_x / norme;
		    float dir_y = deplacement_y / norme;

		    cursor_x -= dir_x * vitesse;
		    cursor_y -= dir_y * vitesse;
		}


		// Contraindre aux bords de l'écran
		if (cursor_x < 0+rad) cursor_x = 0+rad;
		if (cursor_x > 479-rad) cursor_x = 479-rad;
		if (cursor_y < 0+rad) cursor_y = 0+rad;
		if (cursor_y > 249-rad) cursor_y = 249-rad;


		switch(etat){
			case Curseur:
				HAL_GPIO_WritePin(LED15_GPIO_Port, LED15_Pin, 1); // LED15 ON
				HAL_GPIO_WritePin(LED14_GPIO_Port, LED14_Pin, 0); // LED14 Off
				if ((!is_on_palette)&&(HAL_GPIO_ReadPin(BP1_GPIO_Port,BP1_Pin)==0)){
						BSP_LCD_SetTextColor(current_color);
						BSP_LCD_FillCircle(cursor_x,cursor_y, rad);
						}
				break;
			case Segment :
				HAL_GPIO_WritePin(LED14_GPIO_Port, LED14_Pin, 1); // LED14 ON
				HAL_GPIO_WritePin(LED15_GPIO_Port, LED15_Pin, 0); // LED15 Off
				if (bp1_new<bp1_old){
					pos_A_x_seg=cursor_x;
					pos_A_y_seg=cursor_y;

				}

				if (bp1_new>bp1_old){
					pos_B_x_seg=cursor_x;
					pos_B_y_seg=cursor_y;
					BSP_LCD_SetTextColor(current_color);
					DrawThickLine(pos_A_x_seg, pos_A_y_seg, pos_B_x_seg, pos_B_y_seg,rad,current_color);
				}
				break;
			case Cercle:
			    HAL_GPIO_WritePin(LED14_GPIO_Port, LED14_Pin, 1); // LED ON
			    HAL_GPIO_WritePin(LED15_GPIO_Port, LED15_Pin, 1); // LED ON (ou autre indication)

			    if (bp1_new < bp1_old) {
			        if (cercle_etape == 0) {
			            centre_cercle_x = cursor_x;
			            centre_cercle_y = cursor_y;
			            cercle_etape = 1;
			        } else {
			            bord_cercle_x = cursor_x;
			            bord_cercle_y = cursor_y;
			            int dx = bord_cercle_x - centre_cercle_x;
			            int dy = bord_cercle_y - centre_cercle_y;
			            int rayon = sqrt(dx * dx + dy * dy);
			            BSP_LCD_SetTextColor(current_color);
			            BSP_LCD_DrawCircle(centre_cercle_x, centre_cercle_y, rayon);
			            cercle_etape = 0;
			        }
			    }
			    break;

			case Remplissage:
			    HAL_GPIO_WritePin(LED14_GPIO_Port, LED14_Pin, 1);
			    HAL_GPIO_WritePin(LED15_GPIO_Port, LED15_Pin, 1);

			    if ((!is_on_palette) && (HAL_GPIO_ReadPin(BP1_GPIO_Port, BP1_Pin) == 0)) {
			        uint32_t target_color = BSP_LCD_ReadPixel(cursor_x, cursor_y);
			        if (target_color != current_color) {
			            flood_fill(cursor_x, cursor_y, target_color, current_color);
			        }
			    }
			    break;
			case Aide:
			    // On passe sur la couche 1 pour overlay
			    BSP_LCD_SelectLayer(1);
			    BSP_LCD_SetTransparency(1, 200); // semi-transparent

			    // Fond uni (semi-transparent via backcolor)
			    BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
			    BSP_LCD_Clear(LCD_COLOR_WHITE);

			    // Titre
			    BSP_LCD_SetFont(&Font20);
			    BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
			    BSP_LCD_DisplayStringAt(50, 20, (uint8_t *)"Aide Paint STM32", CENTER_MODE);

			    // Instructions
			    BSP_LCD_SetFont(&Font12);
			    BSP_LCD_DisplayStringAt(10, 60, (uint8_t *)"Curseur : dessinez en maintenant BP1", LEFT_MODE);
			    BSP_LCD_DisplayStringAt(10, 80, (uint8_t *)"Segment : 1er appui=debut, 2e=fin", LEFT_MODE);
			    BSP_LCD_DisplayStringAt(10, 100, (uint8_t *)"Cercle : appuyer 2 fois (centre puis rayon)", LEFT_MODE);
			    BSP_LCD_DisplayStringAt(10, 120, (uint8_t *)"Remplissage : 1 appui dans zone fermee", LEFT_MODE);
			    BSP_LCD_DisplayStringAt(10, 140, (uint8_t *)"Attention ne pas remplir en zone ouvert sinon ERREUR", LEFT_MODE);
			    BSP_LCD_DisplayStringAt(10, 160, (uint8_t *)"UART : BP2 pour envoyer le dessin", LEFT_MODE);
			    BSP_LCD_DisplayStringAt(10, 180, (uint8_t *)"Pour fermer le tutoriel, cliquez sur un autre mode", LEFT_MODE);



				break;

		}
		BSP_LCD_SelectLayer(0);


		// Dessiner le nouveau curseur

		BSP_LCD_SelectLayer(1);
		BSP_LCD_SetTextColor(current_color);
		BSP_LCD_FillCircle(cursor_x, cursor_y, rad);
		if ((cursor_x!=prev_cursor_x)||(cursor_y!=prev_cursor_y))
		{
		BSP_LCD_SetTextColor(00);
		BSP_LCD_FillCircle(prev_cursor_x, prev_cursor_y, rad);
		}
		BSP_LCD_SelectLayer(0);


		if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET) { // BP1 appuyé
			// vérifier si on est sur un carré de couleur
			for (int i = 0; i < COLOR_COUNT; i++) {
				int x = i * 20;
				int y = 250;
				if (TS_State.touchX[0] >= x && TS_State.touchX[0] <= x + 20 &&
					TS_State.touchY[0] >= y && TS_State.touchY[0] <= y + 20) {
					current_color = color_palette[i];
				}
			}
		if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET) {
			if ((TS_State.touchX[0] >= 0) && (TS_State.touchX[0] <= 30) &&
					(TS_State.touchY[0] >= 222) && (TS_State.touchY[0] <= 252)) {
			      etat = Segment; //



			    }
			if ((TS_State.touchX[0] >= 0) && (TS_State.touchX[0] <= 30) &&
					(TS_State.touchY[0] >= 192) && (TS_State.touchY[0] <= 222)) {
					etat = Curseur; //



				}
			if ((TS_State.touchX[0] >= 0) && (TS_State.touchX[0] <= 30) &&
			    (TS_State.touchY[0] >= 162) && (TS_State.touchY[0] <= 192)) {
			    etat = Cercle;



				}
			if ((TS_State.touchX[0] >= 0) && (TS_State.touchX[0] <= 30) &&
			    (TS_State.touchY[0] >= 132) && (TS_State.touchY[0] <= 162)) {
			    etat = Remplissage;



			}
			// Si on touche le bouton Aide
			if ((TS_State.touchX[0] >= 0) && (TS_State.touchX[0] <= 30) &&
			    (TS_State.touchY[0] >= 104) && (TS_State.touchY[0] <= 134)) {
			    etat_precedent = etat;  // mémoriser l'état courant
			    etat = Aide;            // passer en mode Aide
			}



			}

			HAL_Delay(30); // anti-rebond

		    if (last_etat == Aide && etat != Aide) {
		        BSP_LCD_SelectLayer(1);
		        BSP_LCD_Clear(0x000000);      // efface tout l’overlay d’aide
		        BSP_LCD_SetTransparency(1,255); // pleine opacité pour voir le curseur
		        BSP_LCD_SelectLayer(0);
		    }
		}

		if (bp2_new<bp2_old)
		{
		    uint16_t pixel;
		    uint8_t b, g, r;
		    char buf[9];
		    for (int16_t y = 272 - 1; y >= 0; y--){
		    for (uint16_t x = 0; x < 480; x++)
		       {
		           // 1) lire le pixel 32 bits
		           pixel = BSP_LCD_ReadPixel(x, y);

		           // 2) extraire les 3 octets de poids faible
		           b = (pixel      ) & 0xFF;   // blue
		           g = (pixel >> 8 ) & 0xFF;   // green
		           r = (pixel >> 16) & 0xFF;   // red

		           // 3) formater en hex ASCII “RRGGBB ”
		           int len = snprintf(buf, sizeof(buf), "%02X%02X%02X ", r, g, b);

		           // 4) envoyer ces 6 caractères + espace
		           HAL_UART_Transmit(&huart1, (uint8_t*)buf, len, HAL_MAX_DELAY);
		       }
		    // send line‑break
		    const char crlf[] = "\r\n";
		    HAL_UART_Transmit(&huart1, (uint8_t*)crlf, sizeof(crlf)-1, HAL_MAX_DELAY);
		    }
		    HAL_Delay(200);
		}


bp1_old=bp1_new;

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 400;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_6) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
